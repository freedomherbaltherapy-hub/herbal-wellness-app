const herbs = [
  {
    name: "Turmeric",
    icon: "🟡",
    description: "A culinary spice traditionally used in food and in some traditional wellness practices."
  },
  {
    name: "Ginger",
    icon: "🫚",
    description: "A widely used culinary root that is also discussed in traditional wellness practices."
  },
  {
    name: "Scent Leaf",
    icon: "🌿",
    description: "An aromatic plant commonly used as a culinary herb in parts of West Africa."
  },
  {
    name: "Bitter Leaf",
    icon: "🍃",
    description: "A leafy plant commonly used as food and in traditional practices in West Africa."
  },
  {
    name: "Clove",
    icon: "🌱",
    description: "An aromatic spice used traditionally in foods and various cultural wellness practices."
  },
  {
    name: "Fenugreek",
    icon: "🌾",
    description: "A plant whose seeds and leaves are used as food and in traditional herbal practices."
  }
];

const grid = document.getElementById("herbGrid");
const search = document.getElementById("searchInput");
const noResults = document.getElementById("noResults");

function renderHerbs(items) {
  grid.innerHTML = items.map(herb => `
    <article class="card">
      <div class="herb-icon">${herb.icon}</div>
      <h3>${herb.name}</h3>
      <p>${herb.description}</p>
    </article>
  `).join("");
  noResults.hidden = items.length !== 0;
}

search.addEventListener("input", () => {
  const term = search.value.toLowerCase().trim();
  const filtered = herbs.filter(h =>
    h.name.toLowerCase().includes(term) ||
    h.description.toLowerCase().includes(term)
  );
  renderHerbs(filtered);
});

document.getElementById("menuBtn").addEventListener("click", () => {
  document.getElementById("navLinks").classList.toggle("open");
});

renderHerbs(herbs);
